let cards = ["46782346", "45781218", "79874568", "12157845", "36151845", "41250895", "41201961"]
let visacount = cards.filter(i => i.startsWith("4")).length;
console.log(visacount + " из " + cards.length);



let string = ''
let answer = []
for(let  i = string.length-1 ; i>=0 ; i--){
    const toArr = string.split('')
    answer.push(toArr[i])
}
console.log(answer.join(""));

let num = Number(prompt("2-10"))
for(let i = 2 ; i<=10 ; i++){
    console.log(num+" * "+i+" = "+num*i);
}


let num1 = Number(prompt("Введите любое число"))
let num2  = 0
for(let i  = 0 ; i<=num1 ; i++){
    num2+=i
}

console.log(num2);






